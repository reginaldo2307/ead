<?php

return array (
  'previous' => '« Previous',
  'next' => 'Next »',
  'of' => 'of',
  'results' => 'results',
  'showing' => 'Showing',
  'to' => 'to',
);
