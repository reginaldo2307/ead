<?php

return array (
  'admin_marks_course_as_pending_title' => 'تم تحديث حالة المقرر الدراسي إلى معلق',
  'admin_marks_course_as_pending_description' => ' :course_name الخاص بك الآن معلق للمراجعة',
  'admin_marks_course_as_active_title' => 'تم تحديث حالة المقرر الدراسي إلى نشط',
  'admin_marks_course_as_active_description' => 'تهانينا! :course_name الخاص بك نشط الآن',
  'student_purchase_course_title' => 'تنبيه شراء الدورة',
  'student_purchase_course_description' => ':student_name اشترت للتو :course_name لـ :amount',
  'student_purchase_bundle_title' => 'تنبيه شراء الحزمة',
  'student_purchase_bundle_description' => ':student_name اشترت للتو :bundle_name لـ :amount',
  'payout_request_approve_title' => 'تمت الموافقة على طلب الدفع',
  'payout_request_approve_description' => 'وافق المسؤول للتو على طلب الدفع الخاص بك البالغ :amount',
  'admin_course_review_submit_title' => 'تمت مراجعة الدورة من قبل المشرف',
  'admin_course_review_submit_description' => 'قام المسؤول بمراجعة :course_name وترك الملاحظات',
  'admin_update_system_revenue_title' => 'تم تحديث شروط الإيرادات',
  'admin_update_system_revenue_description' => 'تم تحديث رسوم النظام لكل دورة / حزمة',
  'admin_allow_publish_course_directly_title' => 'تم تحديث أذوناتك لنشر الدورة التدريبية',
  'admin_allow_publish_course_directly_description' => 'يسمح لك المسؤول بنشر الدورات مباشرة على الموقع',
  'admin_disallow_publish_course_directly_title' => 'تم تحديث أذوناتك لنشر الدورة التدريبية',
  'admin_disallow_publish_course_directly_description' => 'لا يسمح لك المسؤول بنشر الدورات مباشرة على الموقع',
);
