<?php

return array (
  'previous' => '" سابق',
  'next' => 'التالي "',
  'of' => 'من',
  'results' => 'النتائج',
  'showing' => 'عرض',
  'to' => 'إلى',
);
