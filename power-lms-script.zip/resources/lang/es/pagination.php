<?php

return array (
  'previous' => '« Anterior',
  'next' => 'próximo »',
  'showing' => 'Demostración',
  'to' => 'a',
  'of' => 'de',
  'results' => 'resultados',
);
