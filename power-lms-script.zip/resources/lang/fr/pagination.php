<?php

return array (
  'previous' => '« Précédent',
  'next' => 'Prochain »',
  'of' => 'de',
  'results' => 'résultats',
  'showing' => 'Montrant',
  'to' => 'à',
);
