<?php
return [
    '1' => "About",
    '2' => "Categories",
    '3' => "Bundles",
    '4' => "Blogs",
    '5' => "Contact"    
];
