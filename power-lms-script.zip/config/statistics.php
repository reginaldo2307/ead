<?php
return [
    'online_courses' => '2769',
    'total_instructors' => '500',
    'free_tutorials' => '637',
    'students' => '9998',
    'enrollments' => '7894',
];
